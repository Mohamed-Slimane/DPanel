jQuery(document).ready(function() {
    jQuery('[data-bs-toggle="tooltip"]').tooltip();
});