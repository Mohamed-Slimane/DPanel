_M='parent'
_L='config_code'
_K='app/new.html'
_J='app/certificate.html'
_I='error_message'
_H='file'
_G='path'
_F='app'
_E='error'
_D='apps'
_C=False
_B='success'
_A=True
import os,pathlib,shutil,socket,subprocess
from django.contrib.auth.hashers import make_password
from django.http import JsonResponse
from django.shortcuts import render
from django.utils import timezone
from django.views import View
from django.contrib import messages
from django.shortcuts import redirect
from django.utils.translation import gettext_lazy as _
from dpanel.forms import AppForm
from dpanel.functions import create_app_server_block,create_venv,create_app,create_uwsgi_config,get_option,install_uwsgi_server,install_nginx_server,paginator
from dpanel.models import App,AppCertificate
from dpanel.ssl import create_domain_ssl
class apps(View):
	def post(G,request):
		F='message';E='False';B=request;C=get_option('uwsgi_status');D=get_option('nginx_status')
		if not C or C==E or not D or D==E:
			if B.POST.get('uwsgi_install'):A=install_uwsgi_server()
			elif B.POST.get('nginx_install'):A=install_nginx_server()
			else:A={_B:_C,F:_('Form validation error')}
		else:A={_B:_C,F:_('There is an existing uwsgi or nginx server installed')}
		return JsonResponse(A)
	def get(C,request):B=request;A=App.objects.all();A=paginator(B,A,int(get_option('paginator','20')));return render(B,'app/apps.html',{_D:A})
class app_user_new(View):
	def post(K,request,serial):
		A=request;B=App.objects.get(serial=serial);C=A.POST.get('username');D=A.POST.get('email');E=A.POST.get('password');H=A.POST.get('superuser')
		if H=='on':F=_A
		else:F=_C
		if C and E and D:
			try:from django.contrib.auth.models import User;I=f"from django.contrib.auth.models import User; User.objects.create_user(username='{C}', email='{D}', password='{E}', is_superuser={F})";G=f'sudo {B.venv_path}/bin/python {B.www_path}/manage.py shell -c "{I}"';os.system(G);messages.success(A,G);messages.success(A,_('User created successfully for app {}').format(B.name))
			except Exception as J:messages.error(A,str(J))
		else:messages.error(A,_('Please enter a username and password and email and try again.'))
		return render(A,_J,{_F:B})
class app_restart(View):
	def get(G,request,serial):
		B=request;C=App.objects.get(serial=serial)
		try:
			D=f"pgrep -f {C.name}";A=subprocess.check_output(D,shell=_A);A=A.decode().strip().split()
			for E in A:subprocess.call(['sudo','kill','-HUP',E])
			messages.success(B,f"Successfully restarted uWSGI app <b>{C.name}</b>.")
		except subprocess.CalledProcessError as F:messages.error(B,f"Error restarting uWSGI app: {F.stderr}")
		return redirect(_D)
class app_certificates(View):
	def get(B,request,serial):A=App.objects.get(serial=serial);return render(request,_J,{_F:A})
class app_certificate_new(View):
	def get(E,request,serial):
		A=request;C=A.GET.get('wildcard')or None;B=App.objects.get(serial=serial)
		try:create_domain_ssl(B.domain,C);AppCertificate.objects.create(app=B);messages.success(A,_('Certificate created successfully'));subprocess.run('sudo systemctl reload nginx',shell=_A,check=_A)
		except Exception as D:messages.error(A,_('Certificate created failed'));messages.warning(A,str(D))
		return redirect('app_certificates',B.serial)
class app_new(View):
	def post(G,request):
		B=request;C=AppForm(B.POST)
		if C.is_valid():A=C.save(commit=_C);from engine.settings import WWW_FOLDER as E;A.www_path=f"{E}{A.domain}";from engine.settings import VENV_FOLDER as F;A.venv_path=f"{F}{A.domain}";pathlib.Path(A.www_path).mkdir(parents=_A,exist_ok=_A);pathlib.Path(A.venv_path).mkdir(parents=_A,exist_ok=_A);D=socket.socket();D.bind(('',0));A.port=D.getsockname()[1];create_app_server_block(A);create_venv(A.venv_path);create_app(A);create_uwsgi_config(A);A.save();os.system(f"sudo systemctl restart nginx");os.system(f"sudo systemctl restart uwsgi.service");messages.add_message(B,messages.SUCCESS,_('App successfully created'));return redirect(_D)
		else:messages.add_message(B,messages.ERROR,_('Form validation error'));return render(B,_K,{'form':C})
	def get(C,request):A=request;B=AppForm(A.POST or None);return render(A,_K,{'form':B})
class app_config(View):
	def post(C,request,serial):
		B=serial;A=request;D=A.POST.get(_L);E=App.objects.get(serial=B)
		try:
			with open(E.nginx_config,'w')as F:F.write(D)
			os.system(f"sudo systemctl restart nginx");os.system(f"sudo systemctl restart uwsgi");messages.success(A,_('App configuration updated successfully'))
		except:messages.error(A,_('Error in updating django_app configuration'))
		return C.get(A,B)
	def get(C,request,serial):
		A=App.objects.get(serial=serial)
		try:B=pathlib.Path(A.nginx_config).read_text()
		except:B=None
		return render(request,'app/config.html',{_F:A,_L:B})
class app_delete(View):
	def get(C,request,serial):
		A=App.objects.get(serial=serial);A.delete()
		try:pathlib.Path('/var/www-deleted').mkdir(parents=_A,exist_ok=_A);shutil.move(A.www_path,str(A.www_path).replace('/www/','/www-deleted/')+str(timezone.now().strftime('_%Y-%m-%d_time_%H.%M.%S')))
		except Exception as B:pass
		try:os.remove(f"/etc/nginx/sites-available/{A.domain}.conf")
		except Exception as B:pass
		try:os.remove(f"/etc/nginx/sites-enabled/{A.domain}.conf")
		except Exception as B:pass
		try:os.remove(f"/etc/uwsgi/apps-available/{A.domain}.ini")
		except Exception as B:pass
		try:os.remove(f"/etc/uwsgi/apps-enabled/{A.domain}.ini")
		except Exception as B:pass
		try:shutil.rmtree(A.venv_path)
		except Exception as B:pass
		try:os.system(f"sudo certbot delete --cert-name {A.domain}")
		except Exception as B:pass
		os.system(f"sudo killall -9 uwsgi");os.system(f"sudo systemctl restart nginx");os.system(f"sudo systemctl restart uwsgi");return redirect(_D)
class app_files(View):
	def get(F,request,serial):
		C=App.objects.get(serial=serial);A=C.www_path;D=[];E=[]
		for B in os.listdir(A):
			if os.path.isfile(os.path.join(A,B)):D.append(B)
			else:E.append(B)
		return render(request,'app/files.html',{_F:C,'files':D,'dirs':E,_G:A,_M:pathlib.Path(A).parent.absolute()})
class app_files_ajax(View):
	def get(G,request,serial):
		F=request;B=App.objects.get(serial=serial);A=F.GET.get(_G)
		if not A.startswith(B.www_path):A=B.www_path
		C=[];D=[]
		for E in os.listdir(A):
			if os.path.isfile(os.path.join(A,E)):C.append(E)
			else:D.append(E)
		C.sort();D.sort();return render(F,'app/inc/files-list.html',{_F:B,'files':C,'dirs':D,_G:A,_M:pathlib.Path(A).parent.absolute()})
class app_files_ajax_upload(View):
	def post(I,request):
		A=request;print(A.POST.get);F=A.POST.get(_F);D=App.objects.get(serial=F);B=A.POST.get(_G);print(B,'   *****  ',D.www_path)
		if not B.startswith(D.www_path):return JsonResponse({_E:1,_B:_C})
		try:
			C=A.FILES[_H]
			if C.name:G=os.path.basename(C.name);open(f"{B}/{G}",'wb').write(C.read())
			E={_E:0,_B:_A}
		except Exception as H:E={_E:1,_I:str(H),_B:_C}
		return JsonResponse(E)
class extract_zip(View):
	def get(G,request):
		B=request;D=B.GET.get(_G);A=B.GET.get(_H);E=B.GET.get('folder')
		try:
			if E=='true':print(A.rsplit('.',1)[0]);shutil.unpack_archive(A,A.rsplit('.',1)[0])
			else:shutil.unpack_archive(A,D)
			C={_E:0,_B:_A}
		except Exception as F:C={_E:1,_I:str(F),_B:_C}
		return JsonResponse(C)
class file_remove(View):
	def get(E,request):
		B=request;A=B.GET.get(_H)
		try:
			if os.path.isfile(A):os.remove(A)
			elif os.path.isdir(A):shutil.rmtree(A)
			C={_E:0,_B:_A}
		except Exception as D:messages.error(B,str(D));C={_E:1,_I:str(D),_B:_C}
		return JsonResponse(C)
class file_edit(View):
	def get(E,request):
		B=request;A=B.GET.get(_H)
		if not os.path.isfile(A):return redirect(_D)
		C=os.path.basename(A)
		with open(A,'r')as A:D=A.read()
		return render(B,'app/text.html',{'text':D,'filename':C})
	def post(C,request):
		A=request;B=A.GET.get(_H);D=A.POST.get('text')
		with open(B,'w')as B:B.write(D)
		messages.success(A,_('File was successfully updated'));return C.get(A)
class uwsgi_restart(View):
	def get(B,request):
		A=request
		try:os.system(f"sudo systemctl restart nginx");os.system(f"sudo systemctl restart uwsgi");messages.success(A,_('uwsgi restarted successfully'))
		except subprocess.CalledProcessError as C:messages.error(A,_('uwsgi restart failed'))
		return redirect(_D)
class nginx_restart(View):
	def get(B,request):
		A=request
		try:os.system(f"sudo systemctl restart nginx");messages.success(A,_('nginx restarted successfully'))
		except subprocess.CalledProcessError as C:messages.error(A,_('nginx restart failed'))
		return redirect(_D)
class server_restart(View):
	def get(B,request):
		A=request
		try:subprocess.run(['reboot']);messages.success(A,_('Server restarted successfully'))
		except subprocess.CalledProcessError as C:messages.error(A,_('Server restart failed'))
		return redirect(_D)