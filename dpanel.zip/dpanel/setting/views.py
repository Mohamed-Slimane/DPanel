import subprocess
from django.contrib import messages
from django.http import JsonResponse
from django.utils.translation import gettext_lazy as _
from django.shortcuts import render,redirect
from django.views import View
from dpanel.functions import save_option
class settings(View):
	def post(E,request):
		D='value';C='key';A=request
		try:
			F=[{C:B,D:A.POST.get(B)}for B in['company_name','company_email','paginator']]
			for B in F:save_option(B[C],B[D])
			messages.success(A,_('Settings saved'));return redirect('settings')
		except:messages.error(A,_('An error occurred while saving settings'));return E.get(A)
	def get(A,request):return render(request,'settings/settings.html')
class about(View):
	def get(A,request):return render(request,'settings/about.html')
class dpanel_update(View):
	def post(G,request):
		E=False;C=True;B='message';A='success';F='wget -O - https://dpanel.de-ver.com/api/update/update.sh | bash'
		try:subprocess.run(F,shell=C,check=C)
		except subprocess.CalledProcessError as D:return JsonResponse({A:E,B:_("Command failed with return code {e.returncode}: {e.stderr}").format(e=D)})
		except FileNotFoundError:return JsonResponse({A:E,B:_("Command not found. Please make sure 'wget' and 'bash' are installed on your system")})
		except Exception as D:return JsonResponse({A:E,B:_("An error occurred: {e}").format(e=D)})
		try:subprocess.run(['systemctl','restart','dpanel']);return JsonResponse({A:C,B:_("Updated successfully")})
		except:pass
		return JsonResponse({A:C,B:_("Updated completed successfully")})