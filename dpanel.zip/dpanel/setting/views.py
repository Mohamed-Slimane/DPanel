from django.contrib import messages
from django.utils.translation import gettext_lazy as _
from django.shortcuts import render,redirect
from django.views import View
from dpanel.functions import save_option
class settings(View):
	def post(E,request):
		D='value';C='key';A=request
		try:
			F=[{C:B,D:A.POST.get(B)}for B in['company_name','company_email','paginator']]
			for B in F:save_option(B[C],B[D])
			messages.success(A,_('Settings saved'));return redirect('settings')
		except:messages.error(A,_('An error occurred while saving settings'));return E.get(A)
	def get(A,request):return render(request,'settings/settings.html')
class about(View):
	def get(A,request):return render(request,'settings/about.html')