_O='Password'
_N='password'
_M='Username'
_L='username'
_K='Domain'
_J='domain'
_I='django'
_H='Name'
_G='name'
_F='Serial'
_E='serial'
_D='ID'
_C='id'
_B=False
_A=True
from django.db import migrations,models
import django.db.models.deletion
class Migration(migrations.Migration):initial=_A;dependencies=[];operations=[migrations.CreateModel(name='App',fields=[(_C,models.BigAutoField(auto_created=_A,primary_key=_A,serialize=_B,verbose_name=_D)),(_E,models.CharField(editable=_B,max_length=500,unique=_A,verbose_name=_F)),('framework',models.CharField(choices=[(_I,'Django'),('flask','Flask'),('bottle','Bottle')],default=_I,max_length=500,verbose_name='Framework')),(_G,models.CharField(max_length=500,verbose_name=_H)),(_J,models.CharField(max_length=50,unique=_A,verbose_name=_K)),('port',models.IntegerField(unique=_A,verbose_name='Port')),('www_path',models.CharField(max_length=5000,verbose_name='Path')),('uwsgi_path',models.CharField(help_text='The folder that contains the wsgi.py file, for example: (mayproject)',max_length=5000,verbose_name='Uwsgi path')),('venv_path',models.CharField(max_length=5000,verbose_name='Environment Path')),('nginx_config',models.CharField(max_length=5000,verbose_name='Nginx config')),('uwsgi_config',models.CharField(max_length=5000,verbose_name='Uwsgi config')),('force_https',models.BooleanField(default=_B,verbose_name='Force HTTPS')),('activated',models.BooleanField(default=_A,verbose_name='Activated'))]),migrations.CreateModel(name='MysqlDatabase',fields=[(_C,models.BigAutoField(auto_created=_A,primary_key=_A,serialize=_B,verbose_name=_D)),(_E,models.CharField(editable=_B,max_length=500,unique=_A,verbose_name=_F)),(_G,models.CharField(max_length=500,unique=_A,verbose_name=_H)),(_L,models.CharField(max_length=500,unique=_A,verbose_name=_M)),(_N,models.CharField(max_length=500,verbose_name=_O))]),migrations.CreateModel(name='Option',fields=[(_C,models.BigAutoField(auto_created=_A,primary_key=_A,serialize=_B,verbose_name=_D)),('key',models.CharField(blank=_A,max_length=50,null=_A,unique=_A,verbose_name='Key')),('value',models.CharField(blank=_A,max_length=5000,null=_A,verbose_name='Value'))]),migrations.CreateModel(name='PostgresDatabase',fields=[(_C,models.BigAutoField(auto_created=_A,primary_key=_A,serialize=_B,verbose_name=_D)),(_E,models.CharField(editable=_B,max_length=500,unique=_A,verbose_name=_F)),(_G,models.CharField(max_length=500,unique=_A,verbose_name=_H)),(_L,models.CharField(max_length=500,unique=_A,verbose_name=_M)),(_N,models.CharField(max_length=500,verbose_name=_O))]),migrations.CreateModel(name='AppCertificate',fields=[(_C,models.BigAutoField(auto_created=_A,primary_key=_A,serialize=_B,verbose_name=_D)),(_E,models.CharField(editable=_B,max_length=500,unique=_A,verbose_name=_F)),(_J,models.CharField(max_length=50,verbose_name=_K)),('created_date',models.DateTimeField(auto_now=_A)),('expire_date',models.DateTimeField()),('app',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='certificate_app',to='dpanel.app',verbose_name='App'))])]