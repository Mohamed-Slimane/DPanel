import os,subprocess
def has_certbot_cert(domain):A=f"/etc/letsencrypt/live/{domain}";return os.path.exists(A)
def create_domain_ssl(domain_name,wildcard=None):
	'sudo certbot --server https://acme-v02.api.letsencrypt.org/directory -d *.example.com --manual --preferred-challenges dns-01 certonly';A=domain_name
	if wildcard:B=f"sudo certbot certonly --manual --no-redirect --preferred-challenges=dns --email admin@{A} --server https://acme-v02.api.letsencrypt.org/directory --agree-tos -d *.{A}"
	elif has_certbot_cert(A):B=f"sudo certbot renew --nginx --cert-name {A}"
	else:B=f"sudo certbot --nginx --agree-tos --no-redirect --email admin@{A} -d {A}"
	subprocess.run(B,shell=True,check=True);os.system(f"sudo ln -s /etc/nginx/sites-available/{A}.conf /etc/nginx/sites-enabled/{A}.conf")