_K='message'
_J='success'
_I='enable'
_H='start'
_G='update'
_F=False
_E='install'
_D='systemctl'
_C='apt'
_B='sudo'
_A=True
import os,pathlib,subprocess
from django.contrib.auth import REDIRECT_FIELD_NAME
from django.contrib.auth.decorators import user_passes_test
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
from django.utils.translation import gettext_lazy as _
from dpanel.models import Option
def super_required(function=None,redirect_field_name=REDIRECT_FIELD_NAME,login_url=None):
	A=function;B=user_passes_test(lambda u:u.is_superuser,login_url=login_url,redirect_field_name=redirect_field_name)
	if A:return B(A)
	return A
def create_app_server_block(app):
	A=app
	try:
		C='/etc/nginx/sites-available';D='/etc/nginx/sites-enabled';pathlib.Path(C).mkdir(parents=_A,exist_ok=_A);pathlib.Path(D).mkdir(parents=_A,exist_ok=_A);B=f"{C}/{A.domain}.conf";os.system(f"sudo touch {B}");E='server\n{{\n    listen 80;\n    listen [::]:80;\n\n    server_name {app.domain};    \n    root {app.www_path};  \n    \n    location / {{\n        include proxy_params;\n        proxy_pass http://0.0.0.0:{app.port};\n    }}\n\n    error_page 404 /404.html;\n\n\n    location ~* \\.(jpg|jpeg|gif|css|png|js|ico|html)$ {{\n        access_log off;\n        expires max;\n    }}\n\n    location ~* \\.(eot|otf|ttf|woff|woff2|svg)$ {{\n\t\tadd_header Access-Control-Allow-Origin *;\n  \t}}\n\n    location ~ /\\.(ht|py|txt|db|html) {{\n        deny  all;\n    }}\n\n    location  /. {{ ## Disable .htaccess and other hidden files\n        return 404;\n    }}\n}}\n'.format(app=A)
		with open(B,'w')as F:F.write(E);A.nginx_config=B
		os.system(f"sudo ln -s {B} {D}/{A.domain}.conf")
	except Exception as G:print(str(G))
def create_uwsgi_config(app):
	A=app
	try:
		D='/etc/uwsgi/apps-available';B='/etc/uwsgi/apps-enabled';pathlib.Path(D).mkdir(parents=_A,exist_ok=_A);pathlib.Path(B).mkdir(parents=_A,exist_ok=_A);C=f"{D}/{A.domain}.ini";os.system(f"sudo touch {C}");E='\n[uwsgi]\n# plugin = http\nprocessname = {app.name}\nprocesses = 1\nthreads = 2\nchdir = {app.www_path}\nmodule = {app.uwsgi_path}.wsgi:application\nhttp = 0.0.0.0:{app.port}\ndaemonize={app.www_path}/log.log\nvacuum = true\nmaster = true\nmax-requests = 1000\nchmod-socket = 666\nvenv = {app.venv_path}\n'.format(app=A)
		with open(C,'w')as F:F.write(E)
		os.system(f"sudo ln -s {C} {B}/{A.domain}.ini");A.uwsgi_config=f"{B}/{A.domain}.ini"
	except Exception as G:print(str(G))
def create_venv(path):
	try:os.system(f"sudo python3 -m venv {path}")
	except Exception as A:print(str(A))
def create_app(app):
	A=app
	try:
		os.system('\n        cd {app.venv_path}\n        chmod 755 -R {app.venv_path}\n        chmod 755 -R {app.www_path}\n        {app.venv_path}/bin/pip install django\n        {app.venv_path}/bin/pip install uwsgi        \n        cd {app.www_path}\n        django-admin startproject {app.uwsgi_path} .   \n        sudo {app.venv_path}/bin/python manage.py collectstatic --noinput   \n        sudo {app.venv_path}/bin/python manage.py migrate   \n        '.format(app=A));import fileinput as C
		for B in C.input(f"{A.www_path}/{A.uwsgi_path}/settings.py",inplace=_A):
			if B.startswith('ALLOWED_HOSTS = '):B=f"ALLOWED_HOSTS = ['{A.domain}']\n"
			print(B,end='')
	except Exception as D:print(str(D))
def check_db_installed(db_command):
	try:import subprocess as A;A.check_output([db_command,'--version']);return _A
	except FileNotFoundError:return _F
def install_nginx_server():
	C='nginx';B='allow';A='ufw'
	try:subprocess.run([_B,_C,_G]);subprocess.run([_B,_C,_E,'-y',C]);subprocess.run([_B,A,B,'80']);subprocess.run([_B,A,B,'http']);subprocess.run([_B,A,B,'Nginx Full']);subprocess.run([_B,A,B,'8080']);subprocess.run([_B,_D,_H,C]);subprocess.run([_B,_D,_I,C]);D=_A;E=_("Nginx Server has been successfully installed");save_option('nginx_status',_A)
	except Exception as F:D=_F;E=_("An error occurred while installing Nginx: {}").format(F)
	return{_J:D,_K:E}
def install_uwsgi_server():
	E='pip';D='python3';A='uwsgi'
	try:
		subprocess.run([_B,_C,_G]);subprocess.run([_B,_C,_E,'-y',A]);subprocess.run([D,'-m',E,_E,A]);subprocess.run([D,'-m',E,_E,'django']);F='/etc/systemd/system/uwsgi.service';G='\n        [Unit]\n        Description=uWSGI Emperor\n        After=syslog.target\n\n        [Service]\n        ExecStart=/usr/local/bin/uwsgi --emperor /etc/uwsgi/apps-enabled\n        Restart=always\n        KillSignal=SIGQUIT\n        Type=notify\n        StandardError=syslog\n        NotifyAccess=all\n\n        [Install]\n        WantedBy=multi-user.target\n        '
		with open(F,'w')as H:H.write(G)
		subprocess.run([_B,_D,_H,A]);subprocess.run([_B,_D,_I,A]);B=_A;C=_("uwsgi Server has been successfully installed");save_option('uwsgi_status',_A)
	except Exception as I:B=_F;C=_("An error occurred while installing uwsgi: {}").format(I)
	return{_J:B,_K:C}
def install_mysql_server():
	C='mysql'
	try:subprocess.run([_B,_C,_G]);subprocess.run([_B,_C,_E,'-y','mysql-server']);subprocess.run([_B,_D,_H,C]);subprocess.run([_B,_D,_I,C]);A=_A;B=_("MySQL Server has been successfully installed");save_option('mysql_status',_A)
	except Exception as D:A=_F;B=_("An error occurred while installing MySQL: {}").format(D)
	return{_J:A,_K:B}
def get_option(key,default=''):
	B=default
	try:
		A=Option.objects.filter(key=key).first()
		if A and A.value!='':B=A.value
	except:pass
	return B
def save_option(key,value):
	B=value;A=key;C=Option.objects.filter(key=A)
	if C:C.update(key=A,value=B)
	else:Option(key=A,value=B).save()
def paginator(request,obj,number=None,page=1):
	C=number;A=Paginator(obj,get_option('paginator','20')if not C else C);D=request.GET.get('page',page)
	try:B=A.page(D)
	except EmptyPage:B=A.page(A.num_pages)
	except PageNotAnInteger:B=A.page(1)
	return B