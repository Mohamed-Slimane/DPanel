_C='django'
_B=False
_A=True
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
class App(models.Model):
	serial=models.CharField(_('Serial'),max_length=500,unique=_A,editable=_B);framework=models.CharField(_('Framework'),max_length=500,choices=[(_C,'Django'),('flask','Flask'),('bottle','Bottle')],default=_C);name=models.CharField(_('Name'),max_length=500);domain=models.CharField(max_length=50,verbose_name=_('Domain'),unique=_A);port=models.IntegerField(_('Port'),unique=_A);www_path=models.CharField(max_length=5000,verbose_name=_('Path'));uwsgi_path=models.CharField(max_length=5000,verbose_name=_('Uwsgi path'),help_text=_('The folder that contains the wsgi.py file, for example: (mayproject)'));venv_path=models.CharField(max_length=5000,verbose_name=_('Environment Path'));nginx_config=models.CharField(max_length=5000,verbose_name=_('Nginx config'));uwsgi_config=models.CharField(max_length=5000,verbose_name=_('Uwsgi config'));force_https=models.BooleanField(verbose_name=_('Force HTTPS'),default=_B);activated=models.BooleanField(verbose_name=_('Activated'),default=_A)
	def __str__(A):return A.name
	def save(A,*B,**C):
		if not A.pk:import uuid;A.serial=uuid.uuid4()
		if not A.name:A.name=A.domain
		super(App,A).save(*B,**C)
class PostgresDatabase(models.Model):
	serial=models.CharField(_('Serial'),max_length=500,unique=_A,editable=_B);name=models.CharField(_('Name'),unique=_A,max_length=500);username=models.CharField(_('Username'),unique=_A,max_length=500);password=models.CharField(_('Password'),max_length=500)
	def __str__(A):return A.name
	def save(A,*B,**C):
		if not A.pk:import uuid;A.serial=uuid.uuid4()
		super(PostgresDatabase,A).save(*B,**C)
class MysqlDatabase(models.Model):
	serial=models.CharField(_('Serial'),max_length=500,unique=_A,editable=_B);name=models.CharField(_('Name'),unique=_A,max_length=500);username=models.CharField(_('Username'),unique=_A,max_length=500);password=models.CharField(_('Password'),max_length=500)
	def __str__(A):return A.name
	def save(A,*B,**C):
		if not A.pk:import uuid;A.serial=uuid.uuid4()
		super(MysqlDatabase,A).save(*B,**C)
class AppCertificate(models.Model):
	serial=models.CharField(_('Serial'),max_length=500,unique=_A,editable=_B);app=models.ForeignKey(App,verbose_name=_('App'),related_name='certificate_app',on_delete=models.CASCADE);created_date=models.DateTimeField(auto_now=_A)
	def __str__(A):return A.app
	def save(A,*B,**C):
		if not A.pk:import uuid;A.serial=uuid.uuid4()
		super(AppCertificate,A).save(*B,**C)
class Option(models.Model):
	key=models.CharField(max_length=50,verbose_name=_('Key'),null=_A,blank=_A,unique=_A);value=models.CharField(max_length=5000,verbose_name=_('Value'),null=_A,blank=_A)
	def __str__(A):return A.key