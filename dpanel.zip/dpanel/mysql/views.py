_B='mysql_databases'
_A=False
import os,subprocess,uuid
from pathlib import Path
from wsgiref.util import FileWrapper
from django.contrib import messages
from django.http import HttpResponse,JsonResponse
from django.shortcuts import render,redirect
from django.utils.datetime_safe import datetime
from django.utils.translation import gettext_lazy as _
from django.views import View
from dpanel.forms import MysqlDatabaseForm
from dpanel.functions import get_option,install_mysql_server,paginator
from dpanel.models import MysqlDatabase
class databases(View):
	def post(E,request):
		D='message';C='success';B=get_option('mysql_status')
		if not B or B=='False':
			if request.POST.get('mysql_install'):A=install_mysql_server()
			else:A={C:_A,D:_('Form validation error')}
		else:A={C:_A,D:_('There is an existing Mysql server installed')}
		return JsonResponse(A)
	def get(C,request):B=request;A=MysqlDatabase.objects.all();A=paginator(B,A,int(get_option('paginator','20')));return render(B,'mysql/databases.html',{'databases':A})
class database_new(View):
	def post(F,request):
		E='-e';D='mysql';C='sudo';B=request;G=MysqlDatabaseForm(B.POST)
		if G.is_valid():
			A=G.save(commit=_A);A.password=str(uuid.uuid4()).replace('-','')[:15]
			try:subprocess.run([C,D,E,f"CREATE DATABASE {A.name};"]);subprocess.run([C,D,E,f"CREATE USER '{A.username}'@'localhost' IDENTIFIED BY '{A.password}';"]);subprocess.run([C,D,E,f"GRANT ALL PRIVILEGES ON {A.name}.* TO '{A.username}'@'localhost';"]);A.save();messages.add_message(B,messages.SUCCESS,_('Database successfully created'))
			except Exception as H:messages.add_message(B,messages.ERROR,str(H));return F.get(B)
			return redirect(_B)
		else:messages.add_message(B,messages.ERROR,_('Form validation error'));return F.get(B)
	def get(C,request):A=request;B=MysqlDatabaseForm(A.POST or None);return render(A,'mysql/new.html',{'form':B})
class database_delete(View):
	def get(B,request,serial):A=MysqlDatabase.objects.get(serial=serial);os.system(f'sudo mysql -e "DROP DATABASE {A.name};"');os.system(f"sudo mysql -e \"DROP USER '{A.username}'@'localhost';\"");A.delete();return redirect(_B)
class database_download(View):
	def get(F,request,serial):
		C=MysqlDatabase.objects.get(serial=serial);Path('/var/server/dpanel/backups/mysql/').mkdir(parents=True,exist_ok=True);A=f"/var/server/dpanel/backups/mysql/{C.name}_{datetime.today().strftime('%d-%m-%Y_%H-%M')}.sql.gz";os.system(f"sudo mysqldump {C.name} | gzip > {A}")
		if os.path.exists(A):D=os.path.getsize(A);E=os.path.basename(A);B=HttpResponse(FileWrapper(open(A,'rb')),content_type='application/gzip');B['Content-Disposition']='attachment; filename=%s'%E;B['Content-Length']=D;return B
		else:return HttpResponse('The file does not exist')